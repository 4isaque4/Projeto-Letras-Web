
  # Wireframe painel Alfabetizador Online

  This is a code bundle for Wireframe painel Alfabetizador Online. The original project is available at https://www.figma.com/design/BtxVEo3PLelZ27vP8hzotS/Wireframe-painel-Alfabetizador-Online.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  