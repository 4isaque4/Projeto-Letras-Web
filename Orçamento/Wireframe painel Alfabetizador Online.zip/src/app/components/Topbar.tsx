import { Search, Bell, User } from "lucide-react";

export default function Topbar() {
  return (
    <header className="h-16 border-b border-gray-300 bg-white px-6 flex items-center justify-between">
      <div className="flex items-center gap-4 flex-1 max-w-xl">
        <Search className="w-5 h-5 text-gray-400" />
        <input
          type="text"
          placeholder="Buscar..."
          className="flex-1 px-4 py-2 border border-gray-300 bg-gray-50 text-sm focus:outline-none focus:border-gray-500"
        />
      </div>

      <div className="flex items-center gap-4">
        <button className="p-2 hover:bg-gray-100 border border-gray-300">
          <Bell className="w-5 h-5 text-gray-600" />
        </button>
        <button className="flex items-center gap-2 px-3 py-2 hover:bg-gray-100 border border-gray-300">
          <User className="w-5 h-5 text-gray-600" />
          <span className="text-sm text-gray-700">Usuário</span>
        </button>
      </div>
    </header>
  );
}
